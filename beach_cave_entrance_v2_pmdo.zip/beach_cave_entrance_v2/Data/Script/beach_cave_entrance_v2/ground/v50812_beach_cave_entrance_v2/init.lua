-- Empty editing scaffold. Destination and return events are not guessed.
return {}
