-- Empty editing scaffold. Destination and return events are intentionally not guessed.
return {}
