-- Native background and tile animations.
return {}
