-- Editable coastal scaffold. Animation is native, not scripted.
local cote_v2_promontoire = {}
return cote_v2_promontoire
