-- Editable coastal scaffold. Animation is native, not scripted.
local cote_v2_terrasse = {}
return cote_v2_terrasse
