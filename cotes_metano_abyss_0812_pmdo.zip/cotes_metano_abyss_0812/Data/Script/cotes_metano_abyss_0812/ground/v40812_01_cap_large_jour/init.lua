-- Native Ground animations; empty editing scaffold.
return {}
