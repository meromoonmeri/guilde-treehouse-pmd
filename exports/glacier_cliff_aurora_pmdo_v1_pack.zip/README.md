# Glacier Cliff Aurora — Ground PMDO 0.8.12

Carte PMDO native et editable : une arene de glace jouable au sommet, une
arrivee sud, une vue vers une foret enneigee et des montagnes, avec le ciel
canonique et l'aurore animee sur deux calques de fond independants.

## Fichier principal

`Data/Ground/glacier_cliff_aurora_v1.rsground` est une vraie serialisation
`RogueEssence.Ground.GroundMap`, version `0.8.12.0`, `TexSize=3`, grille de
collision 72 x 54 cellules de 8 px. Le terrain jouable est une surface
continue ; les parois, le rebord avant et tout le decor de fond sont bloques.

Le tileset `Content/Tile/VastIceMountain.tile` est copie byte a byte depuis la
ressource native PMDO. Les calques du Ground sont :

1. sol praticable `VastIceMountain` / AutoTile Floor ;
2. parois et rebords `VastIceMountain` / AutoTile Wall ;
3. details secondaires `VastIceMountain` / AutoTile Secondary ;
4. calque reserve au decor d'arriere-plan ;
5. rebord de glace d'avant-plan, `Layer=4`.

## Fonds et provenance

Les fonds sont des `.dir` PMDO separes. Les pixels sont issus des references
canoniques suivantes : `aurorepmdsky.png`, `iceroadpmdsky.png`,
`bgnightbackgroundpmdskyda.png`, `source/references_54d3731/path.png` et
`source/references_54d3731/snow.png` pour les arbres enneiges. Le generateur
les recupere au debut du build, les copie byte a byte dans
`provenance/references/` et arrete la production si un hash change. Les bandes
montagne/foret sont des crops de pixels natifs documentes dans
`provenance/provenance.json`. L'aurore utilise la frame canonique comme source,
puis un cycle de palette de 6 frames dans `GLACIER_AURORA_PALETTE_CYCLE.dir` ;
le ciel `GLACIER_NIGHT_BASE.dir` reste immobile et independant.

Le dossier `layers/` expose la pile demandee : nuit, aurore, montagnes,
foret en contrebas, reference de materiau d'arene, chemin d'acces, sol
d'arene, parois, rebord avant et collision. Les sept premiers sont des
sources/crops ou des references canoniques ; les cinq derniers sont des
reconstructions de controle depuis `VastIceMountain.tile`, pas des textures
inventees. Le Ground PMDO et ses `.dir`/`.tile` restent les fichiers a
importer.

Le guide genere
`renders/glacier_cliff_aurora_v3/raw/native_tileset_reference_composition_magenta.png` a ete
compose avec les previews raster du vrai tileset `VastIceMountain.tile` et les
references canoniques. Il n'est pas importe dans le Ground et n'est pas une
texture de jeu.

L'aurore livree est un calque anime independant : 6 frames derivees par
palette cycling depuis la frame canonique, avec le ciel masque en transparence.
Ce cycle est une adaptation de composition, pas une animation officielle
attribuee a la source. Le fichier `.dir` et les frames derivees sont declares
explicitement dans `provenance/provenance.json`.

## Installation

Extraire l'archive dans un dossier temporaire puis lancer :

```sh
python INSTALLER.py /chemin/PMDO/MODS/mon_mod --dry-run
python INSTALLER.py /chemin/PMDO/MODS/mon_mod
```

L'installateur fusionne l'index des tilesets, ne remplace pas une carte editee
et copie aussi le script sous le namespace `glacier_cliff_aurora`. Pour une
ouverture directe en projet separe, le dossier contient deja `Mod.xml` et un
`Content/Tile/index.idx` autonome.

## Marqueurs

- `entrance` et `entrance_sud` : arrivee praticable au sud ;
- `arena_seuil` : point de raccord au nord de l'arene.

Ces marqueurs ne choisissent pas un donjon absent du projet utilisateur. Il
faut les relier au quest concerné pour une transition narrative.

## Validation et limites

Les tests de structure, de provenance, de references de tuiles et de
connectivite des collisions sont fournis dans `verification.json`. Le vrai
chargeur natif PMDO 0.8.12 a aussi deserialise cette carte en mode headless :
`Width=72`, `Height=54`, `TexSize=3`, `5` calques — PASS.

Ce test ne lance pas l'editeur graphique, le GPU, les deplacements ou les
animations affichees. Le PNG de preview est une reconstruction de controle,
pas une nouvelle texture canonique. La transition vers un donjon doit encore
etre liee au quest utilisateur via `arena_seuil`.
