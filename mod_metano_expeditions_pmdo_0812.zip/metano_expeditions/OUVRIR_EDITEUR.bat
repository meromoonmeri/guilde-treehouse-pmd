@echo off
cd /d "%~dp0..\.."
if exist "PMDO.exe" (
  start "" "PMDO.exe" -dev -quest metano_expeditions
) else if exist "PMDC.exe" (
  start "" "PMDC.exe" -dev -quest metano_expeditions
) else (
  echo Placer metano_expeditions dans le dossier MODS de PMDO.
  pause
)
