#!/usr/bin/env bash
set -e
cd -- "$(dirname -- "$0")/../.."
if [[ -x ./PMDO ]]; then exec ./PMDO -dev -quest metano_expeditions; fi
if [[ -x ./PMDC ]]; then exec ./PMDC -dev -quest metano_expeditions; fi
echo "Placer metano_expeditions dans le dossier MODS de PMDO." >&2
exit 1
