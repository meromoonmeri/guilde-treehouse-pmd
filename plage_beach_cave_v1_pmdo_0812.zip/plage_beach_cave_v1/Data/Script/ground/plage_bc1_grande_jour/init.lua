--[[
    init.lua — plage_bc1_grande_jour
    Squelette d'édition pour PMDO 0.8.12 (lot plage_beach_cave_v1).
    Les deux déclencheurs existent dans le Ground ; leurs destinations sont
    à renseigner dans le projet cible (aucune zone n'est présumée).
    Référence : Data/Script/eos/ground/beach/init.lua d'Explorers of Sky Origins
    (Exit -> crossroads_south / BeachEntranceMarker ; Beach_Cave_Entrance -> zone beach_cave).
]]--
local plage_bc1_grande_jour = {}

function plage_bc1_grande_jour.Init(map)
end

function plage_bc1_grande_jour.Enter(map)
  GAME:FadeIn(20)
end

function plage_bc1_grande_jour.Exit(map)
  GAME:FadeOut(false, 20)
end

function plage_bc1_grande_jour.Update(map)
end

function plage_bc1_grande_jour.GameSave(map)
end

function plage_bc1_grande_jour.GameLoad(map)
  GAME:FadeIn(20)
end

-- Bord droit : retour vers la carte précédente (à raccorder).
function plage_bc1_grande_jour.Exit_Touch(obj, activator)
  -- GAME:EnterGroundMap("<carte>", "<marqueur>")
end

-- Bouche de la grotte, à gauche : entrée du donjon (à raccorder).
function plage_bc1_grande_jour.Beach_Cave_Entrance_Touch(obj, activator)
  -- GAME:EnterZone("<zone>", 0, 0, 0)
end

return plage_bc1_grande_jour
