@echo off
cd /d "%~dp0..\.."
if exist "PMDO.exe" (
  start "" "PMDO.exe" -dev -quest plage_beach_cave_v1
) else if exist "PMDC.exe" (
  start "" "PMDC.exe" -dev -quest plage_beach_cave_v1
) else (
  echo Placer plage_beach_cave_v1 dans le dossier MODS de PMDO.
  pause
)
