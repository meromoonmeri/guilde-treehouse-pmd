#!/usr/bin/env bash
set -e
cd -- "$(dirname -- "$0")/../.."
if [[ -x ./PMDO ]]; then exec ./PMDO -dev -quest plage_beach_cave_v1; fi
if [[ -x ./PMDC ]]; then exec ./PMDC -dev -quest plage_beach_cave_v1; fi
echo "Placer plage_beach_cave_v1 dans le dossier MODS de PMDO." >&2
exit 1
