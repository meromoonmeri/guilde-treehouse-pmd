--[[
    init.lua — plage_cv2_crique
    Squelette d'édition pour PMDO 0.8.12 (lot plage_cote_v2, layout « crique »).
    Les deux déclencheurs existent dans le Ground ; leurs destinations sont
    à renseigner dans le projet cible (aucune zone n'est présumée).
    Référence : Data/Script/eos/ground/beach/init.lua d'Explorers of Sky Origins
    (Exit -> crossroads_south ; Beach_Cave_Entrance -> zone beach_cave).
]]--
local plage_cv2_crique = {}

function plage_cv2_crique.Init(map)
end

function plage_cv2_crique.Enter(map)
  GAME:FadeIn(20)
end

function plage_cv2_crique.Exit(map)
  GAME:FadeOut(false, 20)
end

function plage_cv2_crique.Update(map)
end

function plage_cv2_crique.GameSave(map)
end

function plage_cv2_crique.GameLoad(map)
  GAME:FadeIn(20)
end

-- Bord droit : retour vers la carte précédente (à raccorder).
function plage_cv2_crique.Exit_Touch(obj, activator)
  -- GAME:EnterGroundMap("<carte>", "<marqueur>")
end

-- Bouche de la grotte, à gauche : entrée du donjon (à raccorder).
function plage_cv2_crique.Beach_Cave_Entrance_Touch(obj, activator)
  -- GAME:EnterZone("<zone>", 0, 0, 0)
end

return plage_cv2_crique
