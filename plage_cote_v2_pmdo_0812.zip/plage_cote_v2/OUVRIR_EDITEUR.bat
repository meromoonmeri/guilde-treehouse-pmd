@echo off
cd /d "%~dp0..\.."
if exist "PMDO.exe" (
  start "" "PMDO.exe" -dev -quest {ns}
) else if exist "PMDC.exe" (
  start "" "PMDC.exe" -dev -quest {ns}
) else (
  echo Placer {ns} dans le dossier MODS de PMDO.
  pause
)
