from pathlib import Path
import io,json,zipfile,xml.etree.ElementTree as ET
import numpy as np
from PIL import Image
R=Path(__file__).resolve().parents[2];O=R/'renders/antre_bassin_v4';P=O/'antre';S=O/'sprites';m=json.loads((O/'manifest.json').read_text());W,H=m['size']
def im(p):return Image.open(p).convert('RGBA')
def a(p):return np.array(im(p))
def merge(layers):
 out=Image.new('RGBA',(W,H))
 for layer in layers:out.alpha_composite(layer)
 return out
static={n:im(P/f'bassin4_{n}.png') for n in m['static']};rocknames=['02_paroi_fond','03_bordure_gauche','04_bordure_droite','05_rebord_bas'];platformnames=['06_disque_natif']+[f'07_pas_japonais_{k}' for k in range(1,4)]
rock=np.maximum.reduce([np.array(static[n])[:,:,3] for n in rocknames])>0;stone=np.array(merge([static[n] for n in platformnames]));dry=rock|(stone[:,:,3]>0)
for n in rocknames:assert np.array_equal(np.array(static[n]),a(R/f'renders/antre_harmonie_v3/antre/harmonie_{n}.png'))
assert m['native_platform_proof']['FrameLength']==10 and len(m['native_platform_proof']['Frames'])==8
contacts=[n for n in m['animated'] if n.startswith('08_')]
for p in range(m['frames']):
 layers=dict(static)
 for n in m['animated']:
  layers[n]=im(P/f'bassin4_{n}_{p:02}.png');arr=np.array(layers[n]);assert layers[n].size==(W,H)
  if n!='00_bassin_regenere':assert not np.any(arr[:,:,3][dry]),(p,n)
  period=8 if n.startswith('08_') else 3 if n.startswith('20_') else 4
  assert np.array_equal(arr,a(P/f'bassin4_{n}_{p%period:02}.png'))
 out=np.array(merge([layers[n] for n in m['order']]));assert np.all(out[:,:,3]==255);assert np.array_equal(out,a(P/f'bassin4_composition_{p:02}.png'));assert np.array_equal(out[stone[:,:,3]>0],stone[stone[:,:,3]>0])
 # Reconstruct the actual native8key full platform sprite from the separated water and stone layers.
 native=Image.new('RGBA',(W,H));native.alpha_composite(im(S/f'plateforme_native_complete_{p%8:02}.png'),tuple(m['platform']['origin']));expected=np.array(native);expected[rock]=0
 recovered=np.array(merge([layers[n] for n in contacts]+[layers[n] for n in platformnames]));assert np.array_equal(recovered,expected)
 for k in range(1,7):
  stream=np.array(layers[f'10_cascade_{k}'])[:,:,3]>0;foam=np.array(layers[f'20_ecume_{k}'])[:,:,3]>0;assert (stream&foam).sum()>=5,(k,p,int((stream&foam).sum()))
with zipfile.ZipFile(P/'antre_bassin_v4.ora') as z:
 ls=[im(io.BytesIO(z.read(l.get('src')))) for l in reversed(ET.fromstring(z.read('stack.xml')).find('stack'))];assert np.array_equal(np.array(merge(ls)),a(P/'COMPOSITION.png'))
assert sum(m['durations_ms'])==4000
assert len({a(S/f'bassin_regenere_{i:02}.png').tobytes() for i in range(4)})==4
assert Image.open(P/'ANIMATION.webp').n_frames==24
assert m['platform']['disc_size']==[72,53]
print('PASS:25layers/24states; unchanged walls and stone RGB; native8pose water reconstructed exactly;4basin poses;4/3/8periods; all6fall/foam junctions overlap every frame; ORA exact; no engine validation.')
