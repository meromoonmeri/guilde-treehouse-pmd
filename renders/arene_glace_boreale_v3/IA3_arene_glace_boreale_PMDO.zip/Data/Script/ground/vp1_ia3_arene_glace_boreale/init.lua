-- Editor base. No forced global zoom or gameplay.
local vp1_ia3_arene_glace_boreale = {}
return vp1_ia3_arene_glace_boreale
