# Beach Extension V2 — pack autonome 07–10

[Ouvrir le viewer](index.html) · [Plan des quatre cartes](BeachExt_plan_extension.png)

Deux T (07/08), une croix (09), une baie coudée (10). 80 PNG de calques natifs 512×512 et 16 atlas lossless contenant 512 frames. Le viewer fonctionne avec ces seuls fichiers, sans charger V1. La sortie 07N est une connexion externe à la carte 05 du lot précédent ; 08E, 09W et 09S restent libres. Les quatre nouvelles cartes sont reliées entre elles en boucle.

Extraire toute l’archive. Au besoin : `python -m http.server 8000`, puis ouvrir `http://localhost:8000/` sur la même machine.

## Export PNG sans perte

Avec Python et Pillow :

```sh
python -m pip install Pillow
python export_png.py           # 8 compositions PNG, jour/nuit
python export_png.py --frames  # mêmes compositions + 512 frames d’animation PNG
```

Les fichiers sont écrits dans `export_png/`. Aucun resampling ; canevas 512×512, grille8px, basenames uniques. Le viewer permet aussi d’exporter une vue ou un calque à l’instant affiché. Désactiver les guides avant un export sans annotations.

La nuit du terrain utilise Abyss exactement. L’archive n’embarque pas le ciel, les nuages, les six anciens modules ou les bruts de génération : ils restent dans le dépôt. Les quatre nouvelles maps sont des modules de terrain, pas des bandes de ciel.

Les tests rapportés concernent les assets et une simulation DOM ; pas de navigateur graphique ni PMDO validé. Collisions, transitions moteur et ajustements complets des contours rocheux restent à réaliser. Les sources de reconstruction et les bruts sont dans le dépôt, pas dans ce ZIP.

## Matière et calques

Cinq générations complètes ont été produites : quatre nouvelles maps et une correction de 07. Sa première sortie avait remplacé l’accès est par une côte infranchissable ; cette version est archivée mais **non utilisée**. La correction rétablit le passage de sable est et ferme les autres parties de ce bord par des rochers.

Références de génération : `DSVFS.png`, les modules V1 05/06, et quatre nouveaux guides. Bruts 1024² archivés en **WebP lossless**, avec égalité RGBA vérifiée face aux PNG générés ; leurs hashes originaux, hashes d’archive et hashes des pixels figurent dans `bruts/provenance.json`. Réduction uniforme en nearest-neighbour à 512² et palette de la plage de référence. Cela reste une **génération référencée PMD, pas une extraction de tuiles natives pixel-identiques**. Références PMD : Nintendo / Creatures / GAME FREAK / Chunsoft.

Chaque carte/mode comprend sable, trois plans rocheux, végétation, eau, écume et un calque par accès : **80 PNG de calques** pour les quatre cartes en jour/nuit. Dimensions natives **512×512**, origine (0,0), alpha binaire, basenames uniques, grille 8 px. Les compositions fusionnées sont aussi conservées en WebP lossless dans le dépôt. L’exporteur produit leurs équivalents PNG sans perte.

Les calques représentent des **surfaces visibles**, pas des volumes complets déplaçables. Certains troncs/ombres peuvent rester dans les partitions minérales ; les dessous cachés ne sont pas reconstruits.

## Raccords

Même standard que V1 : accès centrés de **96 px**, coordonnées de bord `[208,304)`, profondeur 48 px, noyau de 16 px identique dans toutes les orientations et transition vers le matériau local. Prélèvement de sable source `(296,168)–(392,216)`.

Les vingt-sept accès déclarés rejoignent leur centre avec une distance d’au moins 8 px aux obstacles du masque de sable. Toutes les bandes de raccord 96×16, dont **05S–07N**, sont comparées pixel par pixel en jour et en nuit.

Ce contrôle **ne certifie pas la continuité complète des falaises** : il peut rester des ajustements de contours rocheux entre deux modules. Ce ne sont ni des collisions ni des warps PMDO. Les limites hors ports doivent être bloquées explicitement en moteur ; des anfractuosités de bord peuvent contenir du sable sans constituer un accès déclaré.

## Animations et ciel conservé

- Eau et écume : deux pistes indépendantes de **32 phases × 100 ms = 3,2 s**, pour chaque nouvelle carte et chaque mode.
- **512 frames** au total dans 16 atlas WebP lossless. Toutes les pistes comportent plusieurs images différentes, pas des copies.
- Liseré périodique jusqu’à 3 px autour du rivage et aux contacts rocheux, reprenant les couleurs de l’écume existante. Le feuillage est exclu ; les rochers restent immobiles. La phase zéro recompose la carte statique exactement.
- Nuit : filtre Abyss exact appliqué au terrain et aux animations, sans mélange de filtres.
- Le **ciel sans lune et les petits nuages de V1 sont conservés**, pas régénérés à nouveau. Ils apparaissent dans la vue du réseau et la plage de référence ; pas entre les cartes. Nuages en wrap de 64 s ; 20 cycles d’eau correspondent à un cycle de nuages. Ne pas leur appliquer Abyss deux fois.

Les quatre nouveaux modules n’embarquent pas de ciel dans leurs PNG de terrain.

