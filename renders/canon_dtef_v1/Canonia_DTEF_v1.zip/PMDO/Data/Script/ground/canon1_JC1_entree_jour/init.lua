-- CANON1 : le cycle provient des frames natives des tuiles ; aucun script requis.
return {}
