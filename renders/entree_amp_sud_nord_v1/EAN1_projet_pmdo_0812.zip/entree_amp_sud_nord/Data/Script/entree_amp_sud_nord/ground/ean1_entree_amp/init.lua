-- ean1_entree_amp : base d edition, aucun warp.
local ean1_entree_amp = {}
return ean1_entree_amp
