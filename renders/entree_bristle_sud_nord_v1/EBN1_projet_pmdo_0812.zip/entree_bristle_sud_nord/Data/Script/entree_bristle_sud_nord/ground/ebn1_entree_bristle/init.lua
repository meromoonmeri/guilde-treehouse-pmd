-- ebn1_entree_bristle : base d edition, aucun warp.
local ebn1_entree_bristle = {}
return ebn1_entree_bristle
