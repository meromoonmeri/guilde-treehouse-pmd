-- ecn1_entree_cascade : base d edition, aucun warp.
local ecn1_entree_cascade = {}
return ecn1_entree_cascade
