-- ecn2_entree_cascade : base d edition, aucun warp.
local ecn2_entree_cascade = {}
return ecn2_entree_cascade
