-- ecf1_entree_cratere_fosse : base d edition, aucun warp.
local ecf1_entree_cratere_fosse = {}
return ecf1_entree_cratere_fosse
