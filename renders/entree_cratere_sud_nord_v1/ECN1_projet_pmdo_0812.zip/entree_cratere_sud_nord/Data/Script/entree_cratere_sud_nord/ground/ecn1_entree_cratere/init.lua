-- ecn1_entree_cratere : base d edition, aucun warp.
local ecn1_entree_cratere = {}
return ecn1_entree_cratere
