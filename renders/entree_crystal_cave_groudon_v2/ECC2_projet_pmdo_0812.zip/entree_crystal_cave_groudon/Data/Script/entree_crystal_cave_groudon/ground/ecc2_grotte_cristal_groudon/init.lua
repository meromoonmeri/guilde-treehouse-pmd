-- ecc2_grotte_cristal_groudon : carte ECC1 + VFX d'arrivee du legendaire (Groudon). Aucun warp.
-- Calques d'evenement [12, 13, 14] (lueur_sol, colonnes_flamme, ecran_chaleur) : invisibles au chargement.
-- ecc2_grotte_cristal_groudon.arrivee_legendaire() : les rend visibles pendant 48 phases x 4 ticks = 192 ticks
-- (3,2 s), puis les recache. A appeler depuis une coroutine de cinematique, juste avant de faire apparaitre Groudon
-- au point (384, 300).
-- NON TESTE DANS PMDO : l'acces Lua a Layers[i].Visible et le calage de la phase 0 des calques d'evenement sur
-- l'horloge d'animation du moteur restent a verifier (sinon l'eruption peut demarrer en cours de cycle).
local ecc2_grotte_cristal_groudon = {}
local EVENEMENT = {12, 13, 14}
local function montrer(visible)
  local carte = GAME:GetCurrentGround()
  for _, i in ipairs(EVENEMENT) do carte.Layers[i].Visible = visible end
end
function ecc2_grotte_cristal_groudon.arrivee_legendaire()
  montrer(true)
  GAME:WaitFrames(192)
  montrer(false)
end
return ecc2_grotte_cristal_groudon
