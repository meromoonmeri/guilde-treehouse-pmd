-- ecc1_entree_crystal_cave : base d edition, aucun warp.
local ecc1_entree_crystal_cave = {}
return ecc1_entree_crystal_cave
