-- edp1_entree_dark_crater_pit : base d edition, aucun warp.
local edp1_entree_dark_crater_pit = {}
return edp1_entree_dark_crater_pit
