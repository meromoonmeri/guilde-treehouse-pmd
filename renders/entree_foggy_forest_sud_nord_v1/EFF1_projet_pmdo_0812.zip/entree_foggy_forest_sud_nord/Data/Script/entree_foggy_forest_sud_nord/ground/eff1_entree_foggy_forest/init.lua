-- eff1_entree_foggy_forest : base d edition, aucun warp.
local eff1_entree_foggy_forest = {}
return eff1_entree_foggy_forest
