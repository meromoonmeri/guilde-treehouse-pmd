-- eff2_entree_foggy_forest_sans_tentes : base d edition, aucun warp.
local eff2_entree_foggy_forest_sans_tentes = {}
return eff2_entree_foggy_forest_sans_tentes
