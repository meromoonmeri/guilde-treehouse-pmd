-- egn1_entree_givre : base d edition, aucun warp.
local egn1_entree_givre = {}
return egn1_entree_givre
