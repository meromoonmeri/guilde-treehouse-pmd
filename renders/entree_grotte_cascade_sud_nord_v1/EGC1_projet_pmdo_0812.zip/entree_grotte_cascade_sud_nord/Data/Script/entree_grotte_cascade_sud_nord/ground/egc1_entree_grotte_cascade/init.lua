-- egc1_entree_grotte_cascade: carte de base; aucune destination de donjon n’est configurée.
local egc1_entree_grotte_cascade = {}
return egc1_entree_grotte_cascade
