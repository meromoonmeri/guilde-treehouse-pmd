-- ehn1_entree_horn : base d edition, aucun warp.
local ehn1_entree_horn = {}
return ehn1_entree_horn
