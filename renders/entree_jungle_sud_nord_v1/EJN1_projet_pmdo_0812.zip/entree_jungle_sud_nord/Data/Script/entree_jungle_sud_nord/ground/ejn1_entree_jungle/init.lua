-- ejn1_entree_jungle : base d edition, aucun warp.
local ejn1_entree_jungle = {}
return ejn1_entree_jungle
