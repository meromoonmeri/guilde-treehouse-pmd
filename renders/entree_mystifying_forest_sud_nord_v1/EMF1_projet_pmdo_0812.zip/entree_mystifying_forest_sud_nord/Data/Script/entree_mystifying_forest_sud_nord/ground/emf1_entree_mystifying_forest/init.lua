-- emf1_entree_mystifying_forest : base d edition, aucun warp.
local emf1_entree_mystifying_forest = {}
return emf1_entree_mystifying_forest
