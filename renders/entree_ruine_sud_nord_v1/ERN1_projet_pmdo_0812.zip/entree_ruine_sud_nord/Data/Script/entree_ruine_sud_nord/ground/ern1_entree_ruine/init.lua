-- ern1_entree_ruine : base d edition, aucun warp.
local ern1_entree_ruine = {}
return ern1_entree_ruine
