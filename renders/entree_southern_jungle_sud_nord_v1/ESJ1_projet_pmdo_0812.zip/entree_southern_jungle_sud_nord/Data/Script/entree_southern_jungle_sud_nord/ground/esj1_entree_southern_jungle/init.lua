-- esj1_entree_southern_jungle : base d edition, aucun warp.
local esj1_entree_southern_jungle = {}
return esj1_entree_southern_jungle
