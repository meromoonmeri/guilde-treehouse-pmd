-- eul1_entree_underground_lake : base d edition, aucun warp.
local eul1_entree_underground_lake = {}
return eul1_entree_underground_lake
