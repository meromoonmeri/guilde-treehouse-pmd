-- esn1_entree_vapeur_jour : base d edition. Aucun warp : raccorder donjon_seuil a votre donjon.
local esn1_entree_vapeur_jour = {}
return esn1_entree_vapeur_jour
