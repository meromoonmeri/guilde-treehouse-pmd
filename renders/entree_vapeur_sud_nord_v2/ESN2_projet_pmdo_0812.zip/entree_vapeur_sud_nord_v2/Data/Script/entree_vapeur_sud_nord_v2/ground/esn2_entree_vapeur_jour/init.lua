-- esn2_entree_vapeur_jour : base d edition, aucun warp.
local esn2_entree_vapeur_jour = {}
return esn2_entree_vapeur_jour
