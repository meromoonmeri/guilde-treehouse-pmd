-- ewc1_entree_waterfall_cave : base d edition, aucun warp.
local ewc1_entree_waterfall_cave = {}
return ewc1_entree_waterfall_cave
