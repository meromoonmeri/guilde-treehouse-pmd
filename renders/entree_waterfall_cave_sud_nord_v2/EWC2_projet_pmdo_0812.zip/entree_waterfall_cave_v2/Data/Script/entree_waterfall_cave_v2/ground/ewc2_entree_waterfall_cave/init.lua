-- ewc2_entree_waterfall_cave : base d edition, aucun warp.
-- Cascade en deux temps. Au chargement, le rideau est ferme (calques [11, 16] visibles).
-- ewc2_entree_waterfall_cave.ouvrir_cascade() : passe a l ouverture (calques [12, 17], 24 phases x 4 ticks
-- = 96 ticks), puis a l etat ouvert (calques [13]). A appeler depuis une coroutine (cinematique).
-- NON TESTE DANS PMDO : l acces Lua a Layers[i].Visible et le calage de la phase 0 du calque d ouverture sur
-- l horloge d animation du moteur restent a verifier.
local ewc2_entree_waterfall_cave = {}
local ETATS = { fermee = {11, 16}, ouverture = {12, 17}, ouverte = {13} }
local function montrer(etat, visible)
  local carte = GAME:GetCurrentGround()
  for _, i in ipairs(ETATS[etat]) do carte.Layers[i].Visible = visible end
end
function ewc2_entree_waterfall_cave.ouvrir_cascade()
  montrer('fermee', false); montrer('ouverture', true)
  GAME:WaitFrames(96)
  montrer('ouverture', false); montrer('ouverte', true)
end
return ewc2_entree_waterfall_cave
