-- ewc3_entree_waterfall_cave : base d edition, aucun warp.
-- Cascade en deux temps. Au chargement, le rideau est ferme (calques [12, 17] visibles).
-- ewc3_entree_waterfall_cave.ouvrir_cascade() : la cascade se fend en deux et s ecarte (calques [13, 18], 24 phases x
-- 4 ticks = 96 ticks), puis reste ouverte (calques [14]). A appeler depuis une coroutine
-- (cinematique). NON TESTE DANS PMDO : l acces Lua a Layers[i].Visible et le calage de la phase 0 du calque
-- d ouverture sur l horloge d animation du moteur restent a verifier.
local ewc3_entree_waterfall_cave = {}
local ETATS = { fermee = {12, 17}, ouverture = {13, 18}, ouverte = {14} }
local function montrer(etat, visible)
  local carte = GAME:GetCurrentGround()
  for _, i in ipairs(ETATS[etat]) do carte.Layers[i].Visible = visible end
end
function ewc3_entree_waterfall_cave.ouvrir_cascade()
  montrer('fermee', false); montrer('ouverture', true)
  GAME:WaitFrames(96)
  montrer('ouverture', false); montrer('ouverte', true)
end
return ewc3_entree_waterfall_cave
