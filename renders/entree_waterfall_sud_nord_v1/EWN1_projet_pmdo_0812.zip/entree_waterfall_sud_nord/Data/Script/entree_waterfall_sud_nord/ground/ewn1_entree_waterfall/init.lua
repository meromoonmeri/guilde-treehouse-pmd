-- ewn1_entree_waterfall : base d edition, aucun warp.
local ewn1_entree_waterfall = {}
return ewn1_entree_waterfall
