local dn1_brulees_entree = {}
return dn1_brulees_entree
