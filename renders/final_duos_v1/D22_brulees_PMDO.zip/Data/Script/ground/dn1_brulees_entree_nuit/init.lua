local dn1_brulees_entree_nuit = {}
return dn1_brulees_entree_nuit
