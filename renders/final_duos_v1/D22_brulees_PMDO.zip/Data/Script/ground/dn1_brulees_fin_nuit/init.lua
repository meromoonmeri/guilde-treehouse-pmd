local dn1_brulees_fin_nuit = {}
return dn1_brulees_fin_nuit
