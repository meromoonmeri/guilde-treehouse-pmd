local dn1_desert_entree = {}
return dn1_desert_entree
