local dn1_desert_entree_nuit = {}
return dn1_desert_entree_nuit
