local dn1_desert_fin = {}
return dn1_desert_fin
