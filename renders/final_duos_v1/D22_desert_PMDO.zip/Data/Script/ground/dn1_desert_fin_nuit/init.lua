local dn1_desert_fin_nuit = {}
return dn1_desert_fin_nuit
