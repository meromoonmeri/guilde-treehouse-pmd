local dn1_discipline_entree = {}
return dn1_discipline_entree
