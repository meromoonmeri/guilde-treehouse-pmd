local dn1_discipline_entree_nuit = {}
return dn1_discipline_entree_nuit
