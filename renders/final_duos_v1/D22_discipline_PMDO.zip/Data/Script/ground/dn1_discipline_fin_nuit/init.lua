local dn1_discipline_fin_nuit = {}
return dn1_discipline_fin_nuit
