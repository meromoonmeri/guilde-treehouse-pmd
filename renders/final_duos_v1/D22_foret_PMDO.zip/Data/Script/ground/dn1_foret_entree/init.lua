local dn1_foret_entree = {}
return dn1_foret_entree
