local dn1_foret_entree_nuit = {}
return dn1_foret_entree_nuit
