local dn1_foret_fin_nuit = {}
return dn1_foret_fin_nuit
