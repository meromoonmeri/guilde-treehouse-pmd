local dn1_ile_entree_nuit = {}
return dn1_ile_entree_nuit
