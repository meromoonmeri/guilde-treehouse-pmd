local dn1_jungle_entree = {}
return dn1_jungle_entree
