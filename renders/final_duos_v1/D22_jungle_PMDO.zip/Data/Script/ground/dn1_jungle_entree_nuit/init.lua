local dn1_jungle_entree_nuit = {}
return dn1_jungle_entree_nuit
