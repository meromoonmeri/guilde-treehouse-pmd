local dn1_lisiere_entree = {}
return dn1_lisiere_entree
