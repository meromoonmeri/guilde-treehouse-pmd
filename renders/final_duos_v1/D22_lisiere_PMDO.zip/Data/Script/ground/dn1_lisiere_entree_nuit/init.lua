local dn1_lisiere_entree_nuit = {}
return dn1_lisiere_entree_nuit
