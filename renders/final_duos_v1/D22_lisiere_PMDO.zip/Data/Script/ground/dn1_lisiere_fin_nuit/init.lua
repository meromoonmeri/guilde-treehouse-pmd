local dn1_lisiere_fin_nuit = {}
return dn1_lisiere_fin_nuit
