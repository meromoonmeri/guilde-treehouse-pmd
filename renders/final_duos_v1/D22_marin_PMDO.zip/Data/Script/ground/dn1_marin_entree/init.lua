local dn1_marin_entree = {}
return dn1_marin_entree
