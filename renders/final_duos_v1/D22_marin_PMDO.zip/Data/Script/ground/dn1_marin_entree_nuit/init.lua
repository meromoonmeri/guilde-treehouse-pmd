local dn1_marin_entree_nuit = {}
return dn1_marin_entree_nuit
