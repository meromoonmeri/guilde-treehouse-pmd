local dn1_marin_fin_nuit = {}
return dn1_marin_fin_nuit
