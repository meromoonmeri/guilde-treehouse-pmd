local dn1_plaines_entree = {}
return dn1_plaines_entree
