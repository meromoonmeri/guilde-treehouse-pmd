local dn1_plaines_entree_nuit = {}
return dn1_plaines_entree_nuit
