local dn1_secrete_entree = {}
return dn1_secrete_entree
