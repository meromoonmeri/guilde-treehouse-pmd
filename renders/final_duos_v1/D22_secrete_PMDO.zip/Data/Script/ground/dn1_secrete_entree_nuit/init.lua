local dn1_secrete_entree_nuit = {}
return dn1_secrete_entree_nuit
