local dn1_volcan_entree = {}
return dn1_volcan_entree
