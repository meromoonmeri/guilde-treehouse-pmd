local dn1_volcan_entree_nuit = {}
return dn1_volcan_entree_nuit
