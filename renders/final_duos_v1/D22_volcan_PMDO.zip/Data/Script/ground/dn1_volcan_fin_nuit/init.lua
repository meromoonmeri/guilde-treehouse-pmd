local dn1_volcan_fin_nuit = {}
return dn1_volcan_fin_nuit
