-- Editor base. No forced global zoom or gameplay.
local vp1_fd1_brulees_fin = {}
return vp1_fd1_brulees_fin
