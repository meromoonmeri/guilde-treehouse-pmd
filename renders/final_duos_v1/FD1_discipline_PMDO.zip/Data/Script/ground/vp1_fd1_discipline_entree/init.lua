-- Editor base. No forced global zoom or gameplay.
local vp1_fd1_discipline_entree = {}
return vp1_fd1_discipline_entree
