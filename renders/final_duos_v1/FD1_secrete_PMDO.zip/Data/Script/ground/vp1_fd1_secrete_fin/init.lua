-- Editor base. No forced global zoom or gameplay.
local vp1_fd1_secrete_fin = {}
return vp1_fd1_secrete_fin
