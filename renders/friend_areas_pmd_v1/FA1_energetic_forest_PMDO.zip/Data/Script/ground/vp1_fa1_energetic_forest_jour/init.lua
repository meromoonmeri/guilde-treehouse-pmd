-- Editor base. No forced global zoom or gameplay.
local vp1_fa1_energetic_forest_jour = {}
return vp1_fa1_energetic_forest_jour
