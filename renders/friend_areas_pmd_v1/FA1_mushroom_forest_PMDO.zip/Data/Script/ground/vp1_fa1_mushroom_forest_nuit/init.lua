-- Editor base. No forced global zoom or gameplay.
local vp1_fa1_mushroom_forest_nuit = {}
return vp1_fa1_mushroom_forest_nuit
