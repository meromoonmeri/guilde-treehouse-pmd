-- Editor base. No forced global zoom or gameplay.
local vp1_gb1_grotte_brumeuse_jour = {}
return vp1_gb1_grotte_brumeuse_jour
