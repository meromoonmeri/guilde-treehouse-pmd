-- Editor base. No forced global zoom or gameplay.
local vp1_gb1_grotte_brumeuse_nuit = {}
return vp1_gb1_grotte_brumeuse_nuit
