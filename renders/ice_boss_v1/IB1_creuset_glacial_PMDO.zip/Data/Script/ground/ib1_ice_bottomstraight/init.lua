local ib1_ice_bottomstraight = {}
return ib1_ice_bottomstraight
