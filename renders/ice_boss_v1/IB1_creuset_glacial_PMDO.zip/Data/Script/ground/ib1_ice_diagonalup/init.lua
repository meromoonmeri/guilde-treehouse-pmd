local ib1_ice_diagonalup = {}
return ib1_ice_diagonalup
