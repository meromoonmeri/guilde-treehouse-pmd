local ib1_ice_topstraight = {}
return ib1_ice_topstraight
