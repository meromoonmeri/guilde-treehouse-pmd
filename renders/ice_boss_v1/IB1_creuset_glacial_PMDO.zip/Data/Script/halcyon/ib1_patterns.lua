return {
TopStraight={leftBottom=false,rightBottom=false,waves={{tick=40,cells={{7,8},{8,8},{7,9},{14,8},{13,8},{14,9}}},{tick=80,cells={{9,8},{10,8},{9,9},{10,9},{12,8},{11,8},{12,9},{11,9}}}}},
BottomStraight={leftBottom=true,rightBottom=true,waves={{tick=40,cells={{7,13},{8,13},{7,12},{14,13},{13,13},{14,12}}},{tick=80,cells={{9,13},{10,13},{9,12},{10,12},{12,13},{11,13},{12,12},{11,12}}}}},
DiagonalDown={leftBottom=false,rightBottom=true,waves={{tick=40,cells={{7,8},{8,8},{7,9},{14,13},{13,13},{14,12}}},{tick=80,cells={{8,9},{9,9},{8,10},{13,12},{12,12},{13,11}}},{tick=120,cells={{9,10},{10,10},{9,11},{10,11},{12,11},{11,11},{12,10},{11,10}}}}},
DiagonalUp={leftBottom=true,rightBottom=false,waves={{tick=40,cells={{7,13},{8,13},{7,12},{14,8},{13,8},{14,9}}},{tick=80,cells={{8,12},{9,12},{8,11},{13,9},{12,9},{13,10}}},{tick=120,cells={{9,11},{10,11},{9,10},{10,10},{12,10},{11,10},{12,11},{11,11}}}}},
}
