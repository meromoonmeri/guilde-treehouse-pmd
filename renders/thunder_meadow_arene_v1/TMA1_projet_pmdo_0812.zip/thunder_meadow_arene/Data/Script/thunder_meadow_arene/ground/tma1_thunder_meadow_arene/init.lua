-- tma1_thunder_meadow_arene : base d edition, aucun warp.
local tma1_thunder_meadow_arene = {}
return tma1_thunder_meadow_arene
