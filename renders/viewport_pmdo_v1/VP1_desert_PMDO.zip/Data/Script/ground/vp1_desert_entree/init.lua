-- Editor base. No forced global zoom or gameplay.
local vp1_desert_entree = {}
return vp1_desert_entree
