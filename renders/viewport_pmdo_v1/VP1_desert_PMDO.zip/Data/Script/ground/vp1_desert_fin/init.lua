-- Editor base. No forced global zoom or gameplay.
local vp1_desert_fin = {}
return vp1_desert_fin
