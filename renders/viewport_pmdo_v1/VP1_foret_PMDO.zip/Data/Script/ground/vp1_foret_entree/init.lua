-- Editor base. No forced global zoom or gameplay.
local vp1_foret_entree = {}
return vp1_foret_entree
