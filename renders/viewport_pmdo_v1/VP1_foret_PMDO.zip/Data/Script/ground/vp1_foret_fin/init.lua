-- Editor base. No forced global zoom or gameplay.
local vp1_foret_fin = {}
return vp1_foret_fin
