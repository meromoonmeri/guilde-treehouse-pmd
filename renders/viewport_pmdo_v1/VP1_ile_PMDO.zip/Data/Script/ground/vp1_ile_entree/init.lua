-- Editor base. No forced global zoom or gameplay.
local vp1_ile_entree = {}
return vp1_ile_entree
