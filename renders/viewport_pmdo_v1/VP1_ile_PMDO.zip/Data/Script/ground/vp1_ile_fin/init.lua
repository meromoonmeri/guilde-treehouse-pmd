-- Editor base. No forced global zoom or gameplay.
local vp1_ile_fin = {}
return vp1_ile_fin
