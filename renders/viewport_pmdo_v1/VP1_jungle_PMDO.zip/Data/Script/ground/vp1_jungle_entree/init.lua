-- Editor base. No forced global zoom or gameplay.
local vp1_jungle_entree = {}
return vp1_jungle_entree
