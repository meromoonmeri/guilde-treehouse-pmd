-- Editor base. No forced global zoom or gameplay.
local vp1_lisiere_entree = {}
return vp1_lisiere_entree
