-- Editor base. No forced global zoom or gameplay.
local vp1_marin_entree = {}
return vp1_marin_entree
