-- Editor base. No forced global zoom or gameplay.
local vp1_marin_fin = {}
return vp1_marin_fin
