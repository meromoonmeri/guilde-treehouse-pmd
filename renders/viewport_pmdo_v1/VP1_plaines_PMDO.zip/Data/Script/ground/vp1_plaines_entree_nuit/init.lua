-- Editor base. No forced global zoom or gameplay.
local vp1_plaines_entree_nuit = {}
return vp1_plaines_entree_nuit
