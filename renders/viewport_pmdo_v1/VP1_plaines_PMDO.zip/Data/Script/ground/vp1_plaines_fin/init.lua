-- Editor base. No forced global zoom or gameplay.
local vp1_plaines_fin = {}
return vp1_plaines_fin
