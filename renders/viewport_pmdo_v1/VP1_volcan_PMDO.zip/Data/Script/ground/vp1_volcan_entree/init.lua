-- Editor base. No forced global zoom or gameplay.
local vp1_volcan_entree = {}
return vp1_volcan_entree
