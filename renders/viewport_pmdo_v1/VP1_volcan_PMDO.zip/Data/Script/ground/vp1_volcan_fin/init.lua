-- Editor base. No forced global zoom or gameplay.
local vp1_volcan_fin = {}
return vp1_volcan_fin
